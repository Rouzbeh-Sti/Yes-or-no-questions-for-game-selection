<?php
    session_start();
    $_SESSION['openworld'] = $_POST['openworld'];

    $multiplayer = $_SESSION['multiplayer'];
    $fps = $_SESSION['fps'];
    $fantasy = $_SESSION['fantasy'];
    $openworld = $_SESSION['openworld'];

    function guessGame($multiplayer, $fps, $fantasy, $openworld) {
        if ($multiplayer == 'yes' && $fps == 'yes' && $fantasy == 'yes' && $openworld == 'yes') {
            return "Destiny 2";
        }
        if ($multiplayer == 'yes' && $fps == 'yes' && $fantasy == 'yes' && $openworld == 'no') {
            return "Overwatch";
        }
        if ($multiplayer == 'yes' && $fps == 'yes' && $fantasy == 'no' && $openworld == 'yes') {
            return "PUBG";
        }
        if ($multiplayer == 'yes' && $fps == 'yes' && $fantasy == 'no' && $openworld == 'no') {
            return "Call of Duty";
        }
        if ($multiplayer == 'yes' && $fps == 'no' && $fantasy == 'yes' && $openworld == 'yes') {
            return "World of Warcraft";
        }
        if ($multiplayer == 'yes' && $fps == 'no' && $fantasy == 'yes' && $openworld == 'no') {
            return "League of Legends";
        }
        if ($multiplayer == 'yes' && $fps == 'no' && $fantasy == 'no' && $openworld == 'yes') {
            return "Minecraft";
        }
        if ($multiplayer == 'yes' && $fps == 'no' && $fantasy == 'no' && $openworld == 'no') {
            return "Among Us";
        }
        // no
        if ($multiplayer == 'no' && $fps == 'yes' && $fantasy == 'yes' && $openworld == 'yes') {
            return "Cyberpunk 2077";
        }
        if ($multiplayer == 'no' && $fps == 'yes' && $fantasy == 'yes' && $openworld == 'no') {
            return "Bioshock Infinite";
        }
        if ($multiplayer == 'no' && $fps == 'yes' && $fantasy == 'no' && $openworld == 'yes') {
            return "Far Cry 5";
        }
        if ($multiplayer == 'no' && $fps == 'yes' && $fantasy == 'no' && $openworld == 'no') {
            return "DOOM";
        }
        if ($multiplayer == 'no' && $fps == 'no' && $fantasy == 'yes' && $openworld == 'yes') {
            return "The Witcher 3";
        }
        if ($multiplayer == 'no' && $fps == 'no' && $fantasy == 'yes' && $openworld == 'no') {
            return "Dragon Age: Inquisition";
        }
        if ($multiplayer == 'no' && $fps == 'no' && $fantasy == 'no' && $openworld == 'yes') {
            return "Red Dead Redemption 2";
        }
        if ($multiplayer == 'no' && $fps == 'no' && $fantasy == 'no' && $openworld == 'no') {
            return "Life is Strange";
        }
        
        return "Unknown Game";
    }

    $guessedGame = guessGame($multiplayer, $fps, $fantasy, $openworld);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Game Guesser - Result</title>
    <style>
        body, html {
            font-family: 'Arial', sans-serif;
            height: 100%;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            box-sizing: border-box;
        }

        .video-background {
            position: fixed;
            right: 0;
            bottom: 0;
            min-width: 100%; 
            min-height: 100%;
            width: auto; 
            height: auto;
            z-index: -100;
            background-size: cover;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
            max-width: 600px;
            margin: 30px auto;
            transition: transform 0.3s ease;
        }
        .container:hover {
    transform: scale(1.05); /* Scale up when hovered */
}

        header {
            background-color: #d1a838fb;
            color: #fff;
            padding: 40px 60px;
            text-align: center;
            border-radius: 8px 8px 0 0;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.85);
        }

        .result-text {
            font-size: 20px;
            color: #333;
            margin-top: 20px;
        }

        .result-text strong {
            color: #bf9249;
            font-size: 22px;
        }
    </style>
</head>
<body>
    <video autoplay muted loop class="video-background">
        <source src="backvid.mp4" type="video/mp4">
        Your browser does not support HTML5 video.
    </video>
    <div class="container">
        <header>
            <h1>Guess the Game (Result)</h1>
        </header>
        <div class="result-text">
            <p>I guess your game is: <strong><?php echo htmlspecialchars($guessedGame); ?></strong></p>
        </div>
    </div>
</body>
</html>
