<?php
    session_start();
    $_SESSION['fantasy'] = $_POST['fantasy'] ?? ''; // Added null coalescing operator for safety
?>
<!DOCTYPE html>
<html>
<head>
    <title>Game Guesser - Question 4</title>
    <style>
        body, html {
            font-family: 'Arial', sans-serif;
            height: 100%;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            box-sizing: border-box;
        }

        .video-background {
            position: fixed;
            right: 0;
            bottom: 0;
            min-width: 100%; 
            min-height: 100%;
            width: auto; 
            height: auto;
            z-index: -100;
            background-size: cover;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
            max-width: 600px;
            margin: 30px auto;
            transition: transform 0.3s ease;
        }
        .container:hover {
    transform: scale(1.05); /* Scale up when hovered */
}

        header {
            background-color: #d1a838fb;
            color: #fff;
            padding: 40px 60px; /* Increased padding for a bigger header */
            text-align: center;
            border-radius: 8px 8px 0 0;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.85);
        }

        form {
            margin-top: 20px;
        }

        .radio-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }

        .radio-container label {
            cursor: pointer;
        }

        .animate-text {
            font-size: 18px;
            color: #000000;
            transition: transform 0.3s ease, color 0.3s ease;
        }
        
        .animate-text:hover {
            transform: scale(1.1);
            color: #c0903e;
        }

        form input[type="radio"] {
            margin-right: 5px;
        }

        form input[type="submit"] {
            display: block;
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #bf9249;
            color: white;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s;
            margin-top: 30px;
        }

        form input[type="submit"]:hover {
            background-color: #d1a838fb;
        }
    </style>
</head>
<body>
    <video autoplay muted loop class="video-background">
        <source src="backvid.mp4" type="video/mp4">
        Your browser does not support HTML5 video.
    </video>
    <div class="container">
        <header>
            <h1>Guess the Game (Question 4)</h1>
        </header>
        <div class="main">
            <form action="result.php" method="post">
                <div class="animate-text">Is it an Open World game?</div>
                <div class="radio-container">
                    <label>
                        <input type="radio" name="openworld" value="yes" required> Yes
                    </label>
                    <label>
                        <input type="radio" name="openworld" value="no" required> No
                    </label>
                </div>
                <input type="submit" value="Next">
            </form>
        </div>
    </div>
</body>
</html>
